﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace ManageEmployee
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindEmployee("");
            }
        }

        protected void BindEmployee(string Emp_Name)
        {
            Test.Service obj = new Test.Service();
            DataSet ds = new DataSet();
            XmlElement exElement = obj.GetEmployeeSearchResult(Emp_Name);
            if (exElement != null)
            {
                XmlNodeReader nodeReader = new XmlNodeReader(exElement);
                ds.ReadXml(nodeReader, XmlReadMode.Auto);
                GridViewEmployee.DataSource = ds;
                GridViewEmployee.DataBind();
            }
            else
            {
                GridViewEmployee.DataSource = null;
                GridViewEmployee.DataBind();
            }
        }
        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            BindEmployee(txtEmpName.Text);
        } 
    }
}